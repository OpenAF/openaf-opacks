from .index import container_plugin

__all__ = ("container_plugin",)
