from textual.demo.demo_app import DemoApp

if __name__ == "__main__":
    app = DemoApp()
    app.run()
