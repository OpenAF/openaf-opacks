ace.define("ace/snippets/svg",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="svg"});
                (function() {
                    ace.require(["ace/snippets/svg"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            