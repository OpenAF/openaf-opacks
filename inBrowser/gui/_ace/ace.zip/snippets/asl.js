define("ace/snippets/asl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="asl"});                (function() {
                    window.require(["ace/snippets/asl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            