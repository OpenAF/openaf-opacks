ace.define("ace/snippets/php_laravel_blade",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="php"});
                (function() {
                    ace.require(["ace/snippets/php_laravel_blade"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            